import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default class AssetExample extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.paragraph}>
          Let's learn english together!
        </Text>
        <Image style={styles.logo} source={require('../assets/eng.png')} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 4,
    backgroundColor: 'lightpink',
    borderRadius: 5
  },
  paragraph: {
    margin: 10,
    marginTop: 0,
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    backgroundColor: 'pink'
  },
  logo: {
    height: 200,
    width: 200,
  }
});
